def start_headless():
    pass
