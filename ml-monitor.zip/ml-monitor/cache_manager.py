class CacheManager:
    pass
