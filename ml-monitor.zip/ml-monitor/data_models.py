class DataModel:
    pass
