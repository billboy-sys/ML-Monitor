#!/bin/bash
python app.py
