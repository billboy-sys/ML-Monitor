#!/bin/bash
docker build -t ml-monitor .
