def search(query):
    return []
